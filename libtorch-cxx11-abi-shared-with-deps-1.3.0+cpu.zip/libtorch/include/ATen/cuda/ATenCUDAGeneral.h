#pragma once

#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_fp16.h>

#include <c10/macros/Export.h>

#define AT_CUDA_API CAFFE2_API
