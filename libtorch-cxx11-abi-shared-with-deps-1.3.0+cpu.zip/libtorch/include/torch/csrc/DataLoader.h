#pragma once

#include <torch/csrc/python_headers.h>

extern PyMethodDef DataLoaderMethods[];
