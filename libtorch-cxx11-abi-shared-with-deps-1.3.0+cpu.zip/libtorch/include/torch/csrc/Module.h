#ifndef THP_MODULE_INC
#define THP_MODULE_INC

#define THP_STATELESS_ATTRIBUTE_NAME "_torch"

#endif
