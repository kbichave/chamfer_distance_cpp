#pragma once

#include <torch/data/transforms/base.h>
#include <torch/data/transforms/collate.h>
#include <torch/data/transforms/lambda.h>
#include <torch/data/transforms/stack.h>
#include <torch/data/transforms/tensor.h>
