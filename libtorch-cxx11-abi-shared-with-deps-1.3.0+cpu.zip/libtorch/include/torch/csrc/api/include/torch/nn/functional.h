#pragma once

#include <torch/nn/functional/distance.h>
#include <torch/nn/functional/pooling.h>
